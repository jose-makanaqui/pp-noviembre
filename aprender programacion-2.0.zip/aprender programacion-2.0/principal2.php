<?php
    include("conexion2.php");
?>

<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap-theme.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  </head>
  <body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
  <a class="navbar-brand" href="inicio3.php">Aprender programacion</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="java.php">Java</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="principal2.php">Datos Personales</a>
      </li>
    </ul>
    <form class="form-inline mt-2 mt-md-0">
      <a class="nav-link" href="cerrar-sesion2.php">cerrar sesion</a>
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    </form>
  </div>
</nav>

    <?php
      session_start();

      // Controlo si el usuario ya está logueado en el sistema.
      if(isset($_SESSION['nombre_usuario'])){
        // Le doy la bienvenida al usuario.
        echo 'Bienvenido <strong>' . $_SESSION['nombre_usuario'];  
          $nombre = $_SESSION['nombre_usuario'];
      }else{
        // Si no está logueado lo redireccion a la página de login.
        header("Location: index2.php");
      }?>
      
      <h1 style="margin-top:2%;" >DATOS PERSONALES</h1>
      
      <table class="table table-dark" style="margin-top:5%;width:50%;">
          <thead>
            <tr>
              <th scope="col">Correo</th>
              <th scope="col">Nombre</th>
              <th scope="col">Apellido</th>
              <th scope="col">Foto Perfil</th>
              <th scope="col">Modificar</th>
            </tr>
          </thead>
          <tbody>
      
      <?php
      $query = "SELECT `id`, `nombre_usuario`, `nombre`, `apellido`, `foto_perfil` FROM usuarios WHERE nombre_usuario = '".$nombre."' ";
                        $envio_consulta = $conexion2->query($query);
                        while($row = $envio_consulta->fetch_assoc()){
                            ?>
                        
                        <tr>
                            <th><?php echo $row['nombre_usuario']; ?></th>
                            <th><?php echo $row['nombre']; ?></th>
                            <th><?php echo $row['apellido']; ?></th>
                            <th> <img style="width:80px;height:50px;" src="data:image/jpg;base64,<?php echo base64_encode($row['foto_perfil'])?>" > </th>
                           <th> <a href="modificar_datos_personales.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Modificar</a></th>
                            
                        </tr>
       <?php } ?>
              
               </tbody>
        </table>
  </body>
</html>