<?php
    include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>Juego de preguntas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        * {
            transition: all 03s;
        }
        
        body {
            padding: 0;
            margin: 0;
            text-align: center;
            font-family: calibri;
            font-size: 120%;
        }
        
        .contenedor {
            width: 98vw;
            height: 97vh;
            display: inline-flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .encabezado {
            position: relative;
            background: white;
            min-width: 300px;
            width: 70%;
            max-width: 600px;
            padding: 10px;
        }
        
        .categoria {
            opacity: 0.3;
            text-align: left;
        }
        
        .pregunta {
            padding: 10px;
        }
        
        .imagen {
            object-fit: cover;
            height: 0px;
            width: 0px;
        }
        
        .btn {
            background: white;
            width: 60%;
            max-width: 550px;
            padding: 10px;
            margin: 5px;
            cursor: pointer;
        }
        
        .btn:hover {
            transform: scale(1.05);
        }
        
        .numero {
            position: absolute;
            opacity: 0.3;
            top: 10px;
            right: 10px;
        }
        
        .puntaje {
            padding: 10px;
            color: white;
        }

        .final{
            top: 10px;
            right: 100px;
        }

        .barra{

        }
    </style>
</head>

<body background="1.gif">

<?php
include("conexion2.php");
  session_start();

  // Controlo si el usuario ya está logueado en el sistema.
  if(isset($_SESSION['nombre_usuario'])){
    $nombre = $_SESSION['nombre_usuario'];
    echo "";
  }else{
    // Si no está logueado lo redireccion a la página de login.
    header("Location: index2.php");
  }
?>

    

    <div class="contenedor">
    <progress style="width: 1020px; padding-left: 300px;" height= 650px id="file" max="100" value="0"> 0% </progress>
    <br>

    <?php
      $query = "SELECT `id`, `nombre_usuario`, `nombre`, `apellido`, `foto_perfil` FROM usuarios WHERE nombre_usuario = '".$nombre."' ";
        $envio_consulta = $conexion2->query($query);
        while($row = $envio_consulta->fetch_assoc()){
        ?>

    <div class="final" id="final" style="display:none;">
    <a href="sumar-exp.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Modificar</a>
    </div>

    <?php } ?>

        <div class="puntaje" id="puntaje"></div>
        <div class="encabezado">
            <div class="categoria" id="categoria">
            </div>
            <div class="numero" id="numero"></div>
            <div class="pregunta" id="pregunta">
            </div>
            <img src="#" class="imagen" id="imagen">
        </div>
        <div class="btn" id="btn1" onclick="oprimir_btn(0)"></div>
        <div class="btn" id="btn2" onclick="oprimir_btn(1)"></div>
        <div class="btn" id="btn3" onclick="oprimir_btn(2)"></div>
        <div class="btn" id="btn4" onclick="oprimir_btn(3)"></div>

        <script src="eljuego2.js"></script>

    </div>

</body>
</html>