<?php
    include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es" dir="ltr" >
  <head>
    <link rel="stylesheet" href="css/bootstrap-theme.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

  </head>
  <body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
  <a class="navbar-brand" href="inicio3.php">Aprender programacion</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="java.php">Java</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="eljuego.php">El juego</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="principal2.php">Datos Personales</a>
      </li>
    </ul>
    <form class="form-inline mt-2 mt-md-0">
      <a class="nav-link" href="cerrar-sesion2.php">cerrar sesion</a>
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    </form>
  </div>
</nav>

<?php
include("conexion2.php");
  session_start();

  // Controlo si el usuario ya está logueado en el sistema.
  if(isset($_SESSION['nombre_usuario'])){
    echo "";
  }else{
    // Si no está logueado lo redireccion a la página de login.
    header("Location: index2.php");
  }
?>

<div>
          <div id="contenedor1">
            <div class="margen1 margen7"><a class="btn btn-outline-dark text-center ancho1 borde" href="Python.php"><h2><b>Python</b></h2></a></div>
            <br>
            <div class="margen2"><a class="btn btn-outline-dark text-center ancho1 borde" ><h2><b>Proximamente</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" ><h2><b>Proximamente</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde"><h2><b>Proximamente</b></h2></a></div>
            <div class="margen1 margen7"><a class="btn btn-outline-dark text-center ancho1 borde" ><h2><b>Proximamente</b></h2></a></div>
          </div>
          <div id="contenedor2">
            <div class="margen2"><a class="btn btn-outline-dark text-center ancho1 borde" ><h2><b>Proximamente</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" ><h2><b>Proximamente</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" ><h2><b>Proximamente</b></h2></a></div>
          </div>
        </div>

</html>
