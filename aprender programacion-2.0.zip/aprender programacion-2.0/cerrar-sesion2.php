<?php
  session_start();

  unset($_SESSION['nombre_usuario']);

  session_destroy();


  // Redirecciona a la página de login.
  header("Location: index2.php");
?>
