<?php

  include("conexion.php");

  // Obtengo los datos cargados en el formulario de login.
  $nombre_usu = $_POST['nombre_usu'];
  $codigo = $_POST['codigo'];
  $nom = $_POST['nom'];
  $ape = $_POST['ape'];
  $foto_perfil = addslashes(file_get_contents($_FILES['foto_perfil']['tmp_name']));

  $sql = "INSERT INTO usuarios(nombre_usuario,codigo,nombre,apellido,foto_perfil) VALUES ('$nombre_usu','$codigo','$nom','$ape','$foto_perfil')";
  $envio_consulta = $conexion->query($sql);
  header("Location: registrado.php");

?>
