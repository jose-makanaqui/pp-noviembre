<?php
    $conexion = new mysqli("localhost","root","","bd_aprender_programacion");
    if ($conexion->connect_errno) {
    echo "Lo sentimos, este sitio web está experimentando problemas.";

    exit;
}
?>
