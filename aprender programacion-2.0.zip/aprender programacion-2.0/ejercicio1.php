<?php
    include("conexion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="funciones.js"></script>
    <style>
  .final{
    margin-top: 430px;
    right: 100px;
    margin-left:1200px;
  }
</style>
</head>

<body>

<?php
include("conexion2.php");
  session_start();

  // Controlo si el usuario ya está logueado en el sistema.
  if(isset($_SESSION['nombre_usuario'])){
    $nombre = $_SESSION['nombre_usuario'];
    echo "";
  }else{
    // Si no está logueado lo redireccion a la página de login.
    header("Location: index2.php");
  }
?>

    <progress style="width: 1020px; padding-left: 300px;" height= 650px id="file" max="100" value="0"> 0% </progress>
    <br>

    <?php
      $query = "SELECT `id`, `nombre_usuario`, `nombre`, `apellido`, `foto_perfil` FROM usuarios WHERE nombre_usuario = '".$nombre."' ";
      $envio_consulta = $conexion2->query($query);
      while($row = $envio_consulta->fetch_assoc()){
      ?>

    <div id="contenido">
    <h2>ejer1</h2>

        <p>Ingrese nombre:<input type="text" autocomplete="off" id="entrada1"></p>
    
    <br>
    <button id="b3" onclick="concatenar1(this)" value="tres">tres</button>
    <button id="b4" onclick="concatenar1(this)" value="cuatro">cuatro</button>
    <button id="b5" onclick="concatenar1(this)" value="cinco">cinco</button>
    <button id="boton-comprobar1" onclick="comprobar1()" >Comprobar</button>
    <button id="boton1" onclick="mostrar('ejer2.txt')" disabled>el que sigue</button> 

    </div>

    <div class="final" id="final" style="display:none;">
    <a href="sumar-exp.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Modificar</a>
    </div>

    <?php } ?>

</body>
</html>