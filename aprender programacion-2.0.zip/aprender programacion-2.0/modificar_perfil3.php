<?php
    include("conexion.php");

    $id = $_REQUEST['id'];

    $nombre = $_POST['nombre'];
	$apellido = $_POST['apellido'];
    $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));


    $query = "UPDATE usuarios SET nombre='$nombre',apellido='$apellido',foto_perfil='$imagen' WHERE id='$id'";
    $envio = $conexion->query($query);

    header("Location:principal2.php");

?>
