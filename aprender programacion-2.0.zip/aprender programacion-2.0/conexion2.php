<?php
    $conexion2 = mysqli_connect("localhost","root","","bd_aprender_programacion");
?>
