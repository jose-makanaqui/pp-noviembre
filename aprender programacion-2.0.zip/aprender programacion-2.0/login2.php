<?php

    session_start();

    include("conexion2.php");

    $nombre_usuario = $_POST['nombre_usuario'];
    $codigo = $_POST['codigo'];

    $validacion;

    $query = mysqli_query($conexion2,"SELECT * FROM usuarios WHERE nombre_usuario = '".$nombre_usuario."' AND codigo = '".$codigo."' " );

    $resultado = mysqli_num_rows($query);


    if($resultado == 1 ){
        $envio_consulta = $conexion2->query($query);
        $_SESSION['nombre_usuario'] = $nombre_usuario;
        $validacion =  $nombre_usuario;
        header("Location: inicio3.php");
    }else{
        $validacion = "Nombre de usuario y/o contraseña incorrectos";
        header("Location: error2.php");
  }

?>
