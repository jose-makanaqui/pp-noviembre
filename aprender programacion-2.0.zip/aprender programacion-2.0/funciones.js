document.onkeydown = function(e) {
    if (e.keyCode === 116) {
        return false;
      }
     //if (e.keyCode === 82) {
    // removes the ctrl+r (page refresh)
        //return false;
        //}

    if (e.key == 1) {
    document.getElementById('entrada1').value = document.getElementById('b3').value;
    }
    if (e.key == 2) {
    document.getElementById('entrada1').value = document.getElementById('b4').value;
    }
    if (e.key == 3) {
    document.getElementById('entrada1').value = document.getElementById('b5').value;
    }
    if (e.key == "Enter") {
        if ((document.getElementById("entrada1").value =="cinco") &&
            (document.getElementById('boton-comprobar1').hasAttribute('disabled') == false ) ) {
            document.getElementById('file').value += 50;
            alert("bien");
            document.getElementById('boton-comprobar1').disabled = true;
            document.getElementById('boton1').disabled = false;
            document.getElementById('entrada1').setAttribute('Disabled',true);
            document.getElementById('b3').setAttribute('Disabled',true);
            document.getElementById('b4').setAttribute('Disabled',true);
            document.getElementById('b5').setAttribute('Disabled',true);
            mostrar('ejer2.txt');
            return false;
        }if( document.getElementById('boton-comprobar1').hasAttribute('disabled') == false ) {
            alert("mal");
            document.getElementById('boton-comprobar1').disabled = true;
            document.getElementById('boton1').disabled = false;
            document.getElementById('entrada1').setAttribute('Disabled',true);
            document.getElementById('b3').setAttribute('Disabled',true);
            document.getElementById('b4').setAttribute('Disabled',true);
            document.getElementById('b5').setAttribute('Disabled',true);
            mostrar('ejer2.txt');
            return false;
        }
        if ((document.getElementById("entrada2").value =="dos") &&
        (document.getElementById('boton-comprobar2').hasAttribute('disabled') == false )) {
            document.getElementById('file').value += 50;
            alert("bien");
            document.getElementById('boton-comprobar2').disabled = true;
            document.getElementById('boton2').disabled = false;
            document.getElementById('entrada2').setAttribute('disabled',true);  
            return false;   
        }if( document.getElementById('boton-comprobar2').hasAttribute('disabled') == false ) {
            alert("mal");
            document.getElementById('boton-comprobar2').disabled = true;
            document.getElementById('boton2').disabled = false;
            document.getElementById('entrada2').setAttribute('Disabled',true);
            return false;
        }else{
            mostrar('ejer3.txt');
        }
    }
    /*if (e.key == "Enter") {
        if (document.getElementById("entrada1").value =="cinco" ) {
            alert("bien");
            document.getElementById('file').value += 30;
            alert("siguiente");
            mostrar('ejer2.txt');
        }else{
            alert("mal");
            mostrar('ejer2.txt');
        }
    }*/

    /*if (e.key == "Enter") {
        if ((document.getElementById("entrada1").value =="cinco") &&
            (document.getElementById('boton-comprobar1').hasAttribute('disabled') == false ) ) {
            document.getElementById('file').value += 30;
            alert("bien");
            document.getElementById('boton-comprobar1').disabled = true;
            document.getElementById('boton1').disabled = false;
            document.getElementById('entrada1').setAttribute('Disabled',true);
        }if( document.getElementById('boton-comprobar1').hasAttribute('disabled') == false ) {
            alert("mal");
            document.getElementById('boton-comprobar1').disabled = true;
            document.getElementById('boton1').disabled = false;
            document.getElementById('entrada1').setAttribute('Disabled',true);
        }else{
            mostrar('ejer2.txt');
        }
    }*/

}

function select_id(id) {
    return document.getElementById(id);
}

function mostrar(ejercicio) {
    while (select_id('file').value >= 100) {
        alert("terminado");
        select_id("final").style.display = '';
        return false;
    }
    fetch(ejercicio)
        .then(response => response.text())
        .then(datos => document.getElementById("contenido").innerHTML = datos);
}

function concatenar1(objeto) {
    document.getElementById('entrada1').value = objeto.value;
    }


/*function boton1() {
    document.getElementById('entrada1').value = document.getElementById('b3').value;
}
    
function boton2() {
    document.getElementById('entrada1').value = document.getElementById('b4').value;
}

function boton3() {
    document.getElementById('entrada1').value = document.getElementById('b5').value;
}*/

function comprobar1() {
    if (document.getElementById("entrada1").value =="cinco") {
        document.getElementById('file').value += 50;
        alert("bien");
        document.getElementById('boton-comprobar1').disabled = true;
        document.getElementById('boton1').disabled = false;
        document.getElementById('entrada1').setAttribute('Disabled',true);
        document.getElementById('b3').setAttribute('Disabled',true);
        document.getElementById('b4').setAttribute('Disabled',true);
        document.getElementById('b5').setAttribute('Disabled',true);
    } else {
        alert("mal");
        document.getElementById('boton-comprobar1').disabled = true;
        document.getElementById('boton1').disabled = false;
        document.getElementById('entrada1').setAttribute('Disabled',true);
        document.getElementById('b3').setAttribute('Disabled',true);
        document.getElementById('b4').setAttribute('Disabled',true);
        document.getElementById('b5').setAttribute('Disabled',true);
    }
  }

function guardarfrase2() {
    let inicia = 30;
    if (document.getElementById("entrada2").value =="dos") {
        document.getElementById('file').value += inicia;
        alert("bien");
        document.getElementById('boton-comprobar2').disabled = true;
        document.getElementById('boton2').disabled = false;
        document.getElementById('entrada2').setAttribute('disabled',true);
    } else {
        alert("mal");
        document.getElementById('boton-comprobar2').disabled = true;
        document.getElementById('boton2').disabled = false;
        document.getElementById('entrada2').setAttribute('disabled',true);
    }
}

function boton1() {
    let bot1 = document.getElementById('b1').value;
    document.getElementById('entrada3').value = bot1;
}

function boton2() {
    let bot2 = "";
    document.getElementById('entrada3').value = bot2;
}

function boton3() {
    let bot3 = document.getElementById('b3').value;
    document.getElementById('entrada3').value = bot3;
}

function comprobar3() {
    let inicie = 30;
    if (document.getElementById("entrada3").value == "tres") {
        document.getElementById('file').value += inicie;
        alert("bien");
        document.getElementById('boton-comprobar3').disabled = true;
        document.getElementById('boton3').disabled = false;
        document.getElementById('entrada3').setAttribute('disabled',true);
        document.getElementById('b1').setAttribute('Disabled',true);
        document.getElementById('b2').setAttribute('Disabled',true);
        document.getElementById('b3').setAttribute('Disabled',true);
    }else{
        alert("mal");
        document.getElementById('boton-comprobar3').disabled = true;
        document.getElementById('boton3').disabled = false;
        document.getElementById('entrada3').setAttribute('disabled',true);
        document.getElementById('b1').setAttribute('Disabled',true);
        document.getElementById('b2').setAttribute('Disabled',true);
        document.getElementById('b3').setAttribute('Disabled',true);
    }
}

function concatenar(objeto) {
    document.getElementById('entrada4').value = objeto.value;
    }

function comprobar4() {
    let inicio = 30;
    if (document.getElementById('entrada4').value == "4") {
        document.getElementById('file').value += inicio;
        document.getElementById('boton-comprobar4').disabled = true;
        document.getElementById('boton4').disabled = false;
        document.getElementById('entrada4').setAttribute('disabled',true);
        alert("bien");
        }else{
        document.getElementById('boton-comprobar4').disabled = true;
        document.getElementById('boton4').disabled = false;
        document.getElementById('entrada4').setAttribute('disabled',true);
        alert("mal");
        }
    }