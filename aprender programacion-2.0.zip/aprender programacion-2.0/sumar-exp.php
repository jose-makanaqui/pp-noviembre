<?php
    include("conexion.php");

    $id = $_REQUEST['id'];
        $query = "SELECT * FROM usuarios WHERE id='$id'";
        $envio = $conexion->query($query);
        $row=$envio->fetch_assoc();

       $experiencia= 20;       
       $sumar_exp= $row['exp'];
       $nueva_exp = $sumar_exp + $experiencia;

       $query2 = "UPDATE usuarios SET exp ='$nueva_exp' WHERE id='$id'";
       $envio2 = $conexion->query($query2);

       header("Location:python.php");

?>