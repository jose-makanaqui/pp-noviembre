<?php
    include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="funciones2.js"></script>
    <style>

<style>

h1 {
  color: #CA7218;
  text-align: center;
}

/* Puzzle */
#contenedorPiezas{
  background: #e7931a;
  width: 600px;
  height: 200px;
  margin-left: 410px;
  box-shadow: 0px 0px 10px  2px #d0eb6a;
}

#puzzle {
  background: #d0eb6a;
  width: 500px;
  height: 200px;
  margin-left: 500px;
  box-shadow: 0px 0px 10px  2px #e7931a;
}
.contenedorPieza1 {
  width: 350px;
  height: 30px;
  float: down;
}

.contenedorPieza2 {
  width: 100px;
  height: 30px;
  float: down;
}

.contenedorPieza3 {
  width: 150px;
  height: 30px;
  float: down;
}

.contenedorPieza4 {
  width: 270px;
  height: 30px;
  float: down;
}

.contenedorPieza5 {
  width: 110px;
  height: 30px;
  float: down;
}

.botoncomprobar {
  margin-left: 1110px;
  height: 40px;
  float: down;
}

.boton-ElSiguiente{
  margin-left: 10px;
  height: 40px;
  float: down;
}
.final{
    margin-top: 430px;
    right: 100px;
    margin-left:1200px;
}

</style>
</head>
<body>

<?php
include("conexion2.php");
  session_start();

  // Controlo si el usuario ya está logueado en el sistema.
  if(isset($_SESSION['nombre_usuario'])){
    $nombre = $_SESSION['nombre_usuario'];
    echo "";
  }else{
    // Si no está logueado lo redireccion a la página de login.
    header("Location: index2.php");
  }
?>

<header>
<progress style="width: 1020px; padding-left: 300px;"   height= 650px id="file" max="100" value="0"> 0% </progress>
<br>
</header>

<?php
    $query = "SELECT `id`, `nombre_usuario`, `nombre`, `apellido`, `foto_perfil` FROM usuarios WHERE nombre_usuario = '".$nombre."' ";
    $envio_consulta = $conexion2->query($query);
    while($row = $envio_consulta->fetch_assoc()){
    ?>

<div id="contenido">

<h2>ejer1</h2>

<p>Hallar la superficie de un cuadrado conociendo el valor de un lado.</p>
<p>coloca las piezas de codigo en su correspondiente orden</p>

<div id="puzzle">
  <div class="contenedorPieza1" id="uno" ondragenter="return enter(event)" ondragover="return over(event)" ondrop="return drop(event)"></div>
  <div class="contenedorPieza2" id="dos" ondragenter="return enter(event)" ondragover="return over(event)" ondrop="return drop(event)"></div>
  <div class="contenedorPieza3" id="tres" ondragenter="return enter(event)" ondragover="return over(event)" ondrop="return drop(event)"></div>
  <div class="contenedorPieza4" id="cuatro" ondragenter="return enter(event)" ondragover="return over(event)" ondrop="return drop(event)"></div>
  <div class="contenedorPieza5" id="cinco" ondragenter="return enter(event)" ondragover="return over(event)" ondrop="return drop(event)"></div>
</div>  

<br>

<div id="contenedorPiezas" ondragenter="return enter(event)" ondragover="return over(event)" ondrop="return drop(event)">
  <button id="pieza3" style="width: 170px;height: 30px;" alt="pieza3" draggable="true" ondragstart="start(event)" ondragend="end(event)">superficie=lado*lado</button>
  <button id="pieza2" style="width: 120px;height: 30px;" alt="pieza2" draggable="true" ondragstart="start(event)" ondragend="end(event)" >lado=int(lado)</button>
  <button id="pieza4" style="width: 300px;height: 30px;" alt="pieza4" draggable="true" ondragstart="start(event)" ondragend="end(event)" >print("La superficie del cuadrado es")</button>
  <button id="pieza1" style="width: 420px;height: 30px;" alt="pieza1" draggable="true" ondragstart="start(event)" ondragend="end(event)" >lado=input("Ingrese la medida del lado del cuadrado:")</button>
  <button id="pieza5" style="width: 130px;height: 30px;" alt="pieza1" draggable="true" ondragstart="start(event)" ondragend="end(event)" >print(superficie)</button>
</div>


<br>

<button class="botoncomprobar" id="botoncomprobar" disabled onclick="comprobarPuzzle()">Comprobar</button>
<button class="boton-ElSiguiente" id="boton1" onclick="mostrar('ejerc2.txt')" disabled>el que sigue</button> 

</div>

<div class="final" id="final" style="display:none;">
  <a href="sumar-exp.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Modificar</a>
</div>

  <?php } ?>
</body>
</html>