function concatenar(objeto) {
  document.getElementById('respuesta1').value = objeto.value
}