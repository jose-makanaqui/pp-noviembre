function comprobar3 () {
    let guardar3;
    let inicio = 20;
    guardar3=document.getElementById("respuesta3").value;
    if (guardar3 =="body") {
      document.getElementById('file').value += inicio;
      alert("Respuesta correcta");
    } 
    else {
      alert("Respuesta incorrecta");
    }
  }
  function mostrar3(ejercicio3) {
    fetch(ejercicio3)
    .then(response => response.text())
    .then(datos => document.getElementById("contenido").innerHTML = datos);
  }