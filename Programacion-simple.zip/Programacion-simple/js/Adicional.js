document.onkeydown = function(e) {
  // keycode for F5 function
  if (e.keyCode === 116) {
    return false;
  }
  if (e.keyCode === 82) {
  // removes the ctrl+r (page refresh)
    return false;
  }
};