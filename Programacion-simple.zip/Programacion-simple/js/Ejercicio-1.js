function comprobar1 () {
    let guardar1;
    let inicio = 20;
    guardar1=document.getElementById("respuesta1").value;
    if (guardar1 =="body") {
      document.getElementById('file').value += inicio;
      alert("Respuesta correcta");
    } 
    else {
      alert("Respuesta incorrecta");
    }
  }
  function mostrar1(ejercicio1) {
    fetch(ejercicio1)
      .then(response => response.text())
      .then(datos => document.getElementById("contenido").innerHTML = datos);
  }