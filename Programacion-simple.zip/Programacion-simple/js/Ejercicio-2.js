function opcion() {
    if {
      let opcion1 = document.getElementById('0').value;
      document.getElementById('respuesta2').value = opcion1;
    }
    else if {
      let opcion2 = document.getElementById('1').value;
      document.getElementById('respuesta2').value = opcion2;
    }
    else if {
      let opcion3 = document.getElementById('2').value;
      document.getElementById('respuesta2').value = opcion3;
    }
    else if {
      let opcion4 = document.getElementById('3').value;
      document.getElementById('respuesta2').value = opcion4;
    }
    else if {
      let opcion5 = document.getElementById('4').value;
      document.getElementById('respuesta2').value = opcion5;
    }
  }
  function comprobar2 () {
    let guardar2
    let inicio= 20;
    guardar2= document.getElementById ('respuesta2').value;
    if (guardar2 == "uno") {
      document.getElementById ('file').value= ++inicio;
      alert ("Respuesta correcta");
    }
    else {
      alert ("Respuesta incorrecta");
    }
  }
  function mostrar2(ejercicio2) {
    fetch(ejercicio2)
      .then(response => response.text())
      .then(datos => document.getElementById("contenido").innerHTML = datos);
  }