<?php
  include ("Verificación-de-inicio-2.php");
  include ("Barra.php");
?>
<html>
  <body>
    <section class="wrapper">
      <section class="container main">
        <form id="cuadro2" action="Obtencion-de-datos.php" method="post">
          <h1 class="text-center margen8">¡Bienvenido otra vez!</h1>
          <br><br>
          <div class="form-floating mb-3">
            <input type="email" class="form-control margen5" placeholder="correo" name="_correo" required>
            <label class="margen4">Correo</label>
          </div>
          <div class="form-floating">
            <input type="password" class="form-control margen5" placeholder="Contraseña" name="clave" required>
            <label class="margen4">Contraseña</label>
          </div>
          <br><br>
          <div class="d-grid col-6 mx-auto">
            <button class="btn btn-lg btn-primary margen7" type="submit">Iniciar sesion</button>
          </div>
        </form>
      </section>
    </section>
  </body>
</html>