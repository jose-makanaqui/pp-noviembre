<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="En esta página vas a aprender lo básico de diversos lenguajes de programación con varios tipos de ejercicios">
    <title>Programación simple</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Estilos.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="funciones.js"></script>
  </head>
  <body>
    <header>
      <nav class="navbar navbar-dark">
        <div class="container-fluid">
          <div class="btn-group">
            <a class="navbar-brand X2" aria-current='page' href="Python.php">X</a>
          </div>
        </div>
      </nav>
    </header>
    <br><br>
    <progress class="barra" id="file" max="100" value="0"> 0% </progress>
    <br>
    <div id="contenido">
      <h3 class="text-center" style="margin-top:3%">ejer1</h3>
      <br><br>
      <form>
        <div class="col-sm-10">
          <input id="entrada1" style="margin-left:10%" type="text" autocomplete="off" class="form-control" placeholder="Respuesta" required>
        </div>
      </form>
      <br>
      <div class="form-group" style="margin-top:2%">
        <button style="margin-left:25%" class="col-sm-2 btn btn-secondary" id="b3" onclick="concatenar1(this)" value="tres">tres</button>
        <button class="col-sm-2 btn btn-secondary" id="b4" onclick="concatenar1(this)" value="cuatro">cuatro</button>
        <button class="col-sm-2 btn btn-secondary" id="b5" onclick="concatenar1(this)" value="cinco">cinco</button>
      </div>
      <br><br>
        <button style="margin-left: 43%" class="btn btn-primary" id="boton-comprobar1" onclick="comprobar1()" >Comprobar</button>
        <button class="btn btn-primary" id="boton1" onclick="mostrar('ejer2.txt')">el que sigue</button>
    </div>
  </body>
</html>