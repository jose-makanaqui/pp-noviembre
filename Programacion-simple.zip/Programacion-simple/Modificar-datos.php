<?php
  include ("Verificación-de-inicio-1.php");
  include ("Conexión.php");
  include ("Barra-de-sesion.php");
?>
<html>
  <body>
    <section class="wrapper">
      <section class="container main">
        <?php
          $id= $_REQUEST ['id'];
          $pedirid= "SELECT * FROM usuarios WHERE id= '$id'";
          $envio= $conexión -> query ($pedirid);
          $mostrar= $envio -> fetch_assoc ();
        ?>
        <form method="POST" id="cuadro4" action="Cargar-nuevos-datos.php?id=<?php echo $mostrar ['id']; ?>" enctype="multipart/form-data">
          <h1 class="text-center margen8">Modificar datos</h1>
          <br><br>
          <div class="mb-3 row">
            <label for="correo" class="col-sm-1 col-form-label margen4">Correo:</label>
            <div class="col-sm-10">
              <input id="correo" class="form-control margen6" type="email" name="nuevo_correo" value="<?php echo $mostrar ['correo']; ?>">
            </div>
          </div>
          <div class="mb-3 row">
            <label for="contraseña" class="col-sm-1 col-form-label margen4">Contraseña:</label>
            <div class="col-sm-10">
              <input id="contraseña" class="form-control margen6" type="password" name="nuevo_clave" value="<?php echo $mostrar ['clave']; ?>">
            </div>
          </div>
          <div class="mb-3 row">
            <label for="nombre" class="col-sm-1 col-form-label margen4">Nombre:</label>
            <div class="col-sm-10">
              <input id="nombre" class="form-control margen6" type="text" name="nuevo_nombre" value="<?php echo $mostrar ['nombre']; ?>">
            </div>
          </div>
          <div class="mb-3 row">
            <label for="apellido" class="col-sm-1 col-form-label margen4">Apellido:</label>
            <div class="col-sm-10">
              <input id="apellido" class="form-control margen6" type="text" name="nuevo_apellido" value="<?php echo $mostrar ['apellido']; ?>">
            </div>
          </div>
          </div>
          <div class="mb-3 row">
            <label for="foto" class="col-sm-1 col-form-label margen4">Foto:</label>
            <div class="col-sm-10">
              <input id="foto" class="form-control margen6" type="file" name="imagen">
              <img class="form-control margen6" type="image" width="200" src="data:image/jpg;base64 <?php echo base64_encode ($mostrar ['foto_perfil']) ?>">
            </div>
          </div>
          <br>
          <div class="d-grid col-6 mx-auto">
            <input style="margin-bottom:2%" type="submit" class="btn btn-lg btn-success" value="Modificar">
            <a class="btn btn-lg btn-danger margen7" href="Datos-personales.php">Cancelar</a>
          </div>
        </form>
      </section>
    </section>
  </body>
</html>