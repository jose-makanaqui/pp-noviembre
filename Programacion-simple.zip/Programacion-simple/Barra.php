<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="En esta página vas a aprender lo básico de diversos lenguajes de programación con varios tipos de ejercicios">
    <link width="10px" height="10px" rel="shortcut icon" type="image/x-icon" href="Imagenes/programación-simple.ico">
    <title>Programación simple</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Estilos.css">
    <script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <header>
      <nav class="navbar navbar-dark navegador">
        <div class="container-fluid">
          <div class="btn-group">
            <a class="navbar-brand" aria-current='page' href="Index.php">Programación simple</a>
          </div>
          <div class="btn-toolbar">
            <div class="btn-group me-2">
              <a class="btn btn-outline-light me-2" href="Iniciar-sesion.php">Iniciar sesion</a>
            </div>
            <div class="btn-group me-2">
              <a class="btn btn-outline-light me-2" href="Crear-cuenta.php">Registrarse</a>
            </div>
          </div>
        </div>
      </nav>
    </header>
  </body>
</html>