<?php
  session_start ();
  include ("Conexión.php");
  $_correo= $_POST ['_correo'];
  $clave= $_POST ['clave'];
  $validacion;
  $query= mysqli_query ($conexión, "SELECT * FROM usuarios WHERE correo= '".$_correo."' AND clave= '".$clave."'");
  $resultado= mysqli_num_rows ($query);
  if ($resultado == 1) {
    $_SESSION ['_correo']= $_correo;
    $validacion= $_correo;
    header ("Location: Nuevo-index.php");
  }
  else {
    header ("Location: Iniciar-sesion.php");
  }
?>