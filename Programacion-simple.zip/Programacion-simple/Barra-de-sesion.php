<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="En esta página vas a aprender lo básico de diversos lenguajes de programación con varios tipos de ejercicios">
    <link width="10px" height="10px" rel="shortcut icon" type="image/x-icon" href="Imagenes/programación-simple.ico">
    <title>Programación simple</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Estilos.css">
    <script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <header>
      <nav class="navbar navbar-dark navegador">
        <div class="container-fluid">
          <div>
            <a class="navbar-brand" href="Nuevo-index.php">Programación simple</a>
          </div>
          <div class="btn-toolbar">
            <div>
              <button type="button" class="btn btn-outline-light boton1 fondo-usuario" data-bs-toggle="dropdown"></button>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a id="lista" class="dropdown-item" href="Cuenta.php">Cuenta</a></li>
                <li><a id="lista" class="dropdown-item" href="Datos-personales.php">Datos personales</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a id="cerrar-sesion" class="dropdown-item" href="Cerrar-sesion.php">Cerrar sesion</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </header>
  </body>
</html>