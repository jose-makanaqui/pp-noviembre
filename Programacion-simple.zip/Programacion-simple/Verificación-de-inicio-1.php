<?php
  include ("Conexión.php");
  session_start ();
  // Controlo si el usuario ya está logueado en el sistema.
  if(isset ($_SESSION ['_correo'])){
    //echo 'Bienvenido <strong>' . $_SESSION['_correo'];
    $usuario= $_SESSION ['_correo'];
  }
  else {
    // Si no está logueado lo redireccion a la página principal.
    header ("Location: Index.php");
  }
?>