<?php
  $conexión= new mysqli ("localhost","root","","programacion-simple");
?>