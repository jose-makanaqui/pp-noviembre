<?php
  include ("Verificación-de-inicio-1.php");
  include ("Barra-de-sesion.php");
?>
<html>
  <body>
    <section class="wrapper">
      <section class="main">
        <h1 class="text-center margen8">Programación simple</h1>
        <div>
          <div>
            <div class="margen13"><a class="btn btn-outline-dark text-center ancho1 borde" href="Trivia.php"><h2><b>Trivia</b></h2></a></div>
          </div>
          <div id="contenedor1">
            <div class="margen2"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>Html</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>C</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>Css</b></h2></a></div>
            <div class="margen1 margen7"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>JavaScript</b></h2></a></div>
          </div>
          <div id="contenedor2">
            <div class="margen2"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>Java</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>Php</b></h2></a></div>
            <div class="margen1"><a class="btn btn-outline-dark text-center ancho1 borde" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><h2><b>Sql</b></h2></a></div>
            <div class="margen1 margen7"><a class="btn btn-outline-dark text-center ancho1 borde" href="Python.php"><h2><b>Python</b></h2></a></div>
          </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <img class="proxima" src="Imagenes/proximamente.png" alt="Imagen">
              </div>
            </div>
          </div>
        </div>
      </section>
    </section>
  </body>
</html>