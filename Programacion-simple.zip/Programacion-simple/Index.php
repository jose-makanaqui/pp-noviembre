<?php
  include ("Verificación-de-inicio-2.php");
?>
<!DOCTYPE html>
<html>
 <head>
    <meta charset="utf-8">
    <meta name="description" content="En esta página vas a aprender lo básico de diversos lenguajes de programación con varios tipos de ejercicios">
    <title>Programación simple</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Estilos.css">
    <script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="fondo-inicio">
      <header>
        <nav class="navbar navbar-dark">
          <div class="container-fluid">
            <div class="margen12">
              <button class="btn" id="bdark">
                <svg width="16" height="16" fill="currentColor" class="bi bi-mask" viewBox="0 0 16 16">
                  <path d="M6.225 1.227A7.5 7.5 0 0 1 10.5 8a7.5 7.5 0 0 1-4.275 6.773 7 7 0 1 0 0-13.546zM4.187.966a8 8 0 1 1 7.627 14.069A8 8 0 0 1 4.186.964z"/>
                </svg>
              </button>
            </div>
            <div class="btn-toolbar">
              <div class="btn-group me-2">
                <a class="btn btn-outline-light me-2" href="Iniciar-sesion.php">Iniciar sesion</a>
              </div>
              <div class="btn-group me-2">
                <a class="btn btn-outline-light me-2" href="Crear-cuenta.php">Registrarse</a>
              </div>
            </div>
          </div>
        </nav>
      </header>
      <h1 class="text-center titulo" style="margin-top:18%">Programación simple</h1>
    </div>
    <div class="margen7 margen3" style="margin-top:8%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/html.png" alt="logo de html"></div>
      <div id="contenedor4"><p>Es un lenguaje de marcado de hipertexto (HyperText Markup) que se utiliza para el desarrollo de páginas web.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/css.png" alt="logo de css"></div>
      <div id="contenedor4"><p>Es un lenguaje usado para definir la presentación de un documento estructurado escrito en HTML y derivados.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/php.png" alt="logo de php"></div>
      <div id="contenedor4"><p>Es un lenguaje de programación de uso general que permite el desarrollo web o aplicaciones web dinámicas, el cual es apto para incrustar el lenguaje HTML, también favorece a la conexión entre el servidor y la interfaz de usuario.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/python.png" alt="logo de python"></div>
      <div id="contenedor4"><p>Se trata de un lenguaje dinámico y versátil de código abierto, es multiplataforma y multiparadigma. Su principal objetivo es la automatización de procesos para ahorrar tiempo y recursos.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/javascript.png" alt="logo de javascript"></div>
      <div id="contenedor4"><p>Es un lenguaje de programación que se aplica a un documento HTML que se usa para añadir características interactivas a tu sitio web como puede ser juegos, animación, efectos de estilo dinámicos, etc.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/sql.png" alt="logo de sql"></div>
      <div id="contenedor4"><p>Es un lenguaje de programación diseñado para actualizar, obtener, y calcular información en bases de datos relacionales.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/c.png" alt="logo de c"></div>
      <div id="contenedor4"><p> Se trata de un lenguaje de programación de tipos de datos estáticos.</p></div>
    </div>
    <hr class="margen11">
    <div class="margen7 margen3" style="margin-top:5%">
      <div id="contenedor3"><img class="imagen" src="Imagenes/java.png" alt="logo de java"></div>
      <div id="contenedor4"><p>Es un lenguaje de programación y una plataforma informática comercializada.</p></div>
    </div>
  </body>
</html>