<?php
  include ("Verificación-de-inicio-2.php");
  include ("Barra.php");
?>
<html>
  <body>
    <section class="wrapper">
      <section class="container main">
        <form id="cuadro1" action="Cargar-datos.php" method="post">
          <h1 class="text-center margen8">¡Bienvenido a nuestra página!</h1>
          <br><br>
          <div class="form-floating mb-3">
            <input type="email" class="form-control margen5" placeholder="Correo" name="correo" required>
            <label class="margen4">Correo</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" class="form-control margen5" placeholder="Contraseña" name="clave" required>
            <label class="margen4">Contraseña</label>
          </div>
          <div class="form-floating mb-3">
            <input type="text" class="form-control margen5" placeholder="Nombre" name="nombre" required>
            <label class="margen4">Nombre</label>
          </div>
          <div class="form-floating">
            <input type="text" class="form-control margen5" placeholder="Apellido" name="apellido" required>
            <label class="margen4">Apellido</label>
          </div>
          <br><br>
          <div class="d-grid col-6 mx-auto">
            <button class="btn btn-lg btn-primary margen7" type="submit">Crear cuenta</button>
          </div>
        </form>
      </section>
    </section>
  </body>
</html>