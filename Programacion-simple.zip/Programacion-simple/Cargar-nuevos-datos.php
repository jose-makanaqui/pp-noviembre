<?php
  include ("Conexión.php");
  $id= $_REQUEST ['id'];
  $nuevo_correo= $_POST ['nuevo_correo'];
  $nuevo_clave= $_POST ['nuevo_clave'];
  $nuevo_nombre= $_POST ['nuevo_nombre'];
  $nuevo_apellido= $_POST ['nuevo_apellido'];
  $imagen= addslashes (file_get_contents ($_FILES ['imagen'] ['tmp_name']));
  $query= "UPDATE usuarios SET correo= '$nuevo_correo', clave= '$nuevo_clave', nombre= '$nuevo_nombre', apellido= '$nuevo_apellido', foto_perfil= '$imagen' WHERE id= '$id'";
  $envio= $conexión -> query ($query);
  header ("Location: Datos-personales.php");
?>