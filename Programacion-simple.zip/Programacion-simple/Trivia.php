<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
    <meta name="description" content="En esta página vas a aprender lo básico de diversos lenguajes de programación con varios tipos de ejercicios">
    <link width="10px" height="10px" rel="shortcut icon" type="image/x-icon" src="Imagenes/programación-simple.ico">
    <title>Programación simple</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
</head>
<body background="fondo-trivia.gif">
    <style>
        * {
            transition: all 03s;
        }
        body {
            padding: 0;
            margin: 0;
            text-align: center;
            font-family: calibri;
            font-size: 120%;
        }
        .contenedor {
            width: 98vw;
            height: 97vh;
            display: inline-flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .encabezado {
            position: relative;
            background: white;
            min-width: 300px;
            width: 70%;
            max-width: 600px;
            padding: 10px;
        }
        .categoria {
            opacity: 0.3;
            text-align: left;
        }
        .pregunta {
            padding: 10px;
        }
        .imagen {
            object-fit: cover;
            height: 0px;
            width: 0px;
        }
        .btn {
            background: white;
            width: 60%;
            max-width: 550px;
            padding: 10px;
            margin: 5px;
            cursor: pointer;
        }
        .btn:hover {
            transform: scale(1.05);
        }
        .numero {
            position: absolute;
            opacity: 0.3;
            top: 10px;
            right: 10px;
        }
        .puntaje {
            padding: 10px;
            color: white;
        }
        .X {
            text-decoration: none;
            color: white;
            font-size: 200%;
            margin-right: 95%;
        }
    </style>
    <header>
      <nav class="navbar navbar-dark">
        <div class="container-fluid">
          <div class="btn-group">
            <a class="navbar-brand X" aria-current='page' href="Nuevo-index.php">X</a>
          </div>
        </div>
      </nav>
    </header>
    <div class="contenedor">
        <div class="puntaje" id="puntaje"></div>
        <div class="encabezado">
            <div class="categoria" id="categoria">
            </div>
            <div class="numero" id="numero"></div>
            <div class="pregunta" id="pregunta">
            </div>
            <img src="#" class="imagen" id="imagen">
        </div>
        <div class="btn" id="btn1" onclick="oprimir_btn(0)"></div>
        <div class="btn" id="btn2" onclick="oprimir_btn(1)"></div>
        <div class="btn" id="btn3" onclick="oprimir_btn(2)"></div>
        <div class="btn" id="btn4" onclick="oprimir_btn(3)"></div>
        <script src="Trivia.js"></script>
    </div>
</body>
</html>