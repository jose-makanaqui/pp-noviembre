<?php
  include ("Verificación-de-inicio-1.php");
  include ("Conexión.php");
  include ("Barra-de-sesion.php");
?>
<html>
  <body>
    <section class="wrapper">
      <section class="container main">
        <?php
          $pedir= "SELECT * FROM usuarios WHERE correo= '".$usuario."'";
          $envio_consulta= $conexión->query ($pedir);
          while ($mostrar= $envio_consulta->fetch_assoc ()){
        ?>
        <form id="cuadro7" method="post">
          <h1 class="text-center margen8">Cuenta</h1>
          <br><br>
          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label margen4">Foto:</label>
            <div class="col-sm-10">
              <img class="form-control margen6" type="image" style="width:100px;height:100px;" src="data:image/jpg;base64, <?php echo base64_encode ($mostrar ['foto_perfil']) ?>" disabled readonly>
            </div>
          </div>
          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label margen4">Nombre:</label>
            <div class="col-sm-10">
              <input class="form-control margen6" type="text" value="<?php echo $mostrar ['nombre']; ?>" disabled readonly>
            </div>
          </div>
          <br>
        </form>
        <?php } ?>
      </section>
    </section>
  </body>
</html>