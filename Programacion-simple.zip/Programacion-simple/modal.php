<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="En esta página vas a aprender lo básico de diversos lenguajes de programación con varios tipos de ejercicios">
    <link width="10px" height="10px" rel="shortcut icon" type="image/x-icon" href="Imagenes/programación-simple.ico">
    <title>Programación simple</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Estilos.css">
    <script src="js/bootstrap.min.js"></script>
  </head><!-- Button trigger modal -->
  <body>

    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
  Launch static backdrop modal
</button>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img class="proxima" src="Imagenes/proximamente.png" alt="Imagen">
      </div>
    </div>
  </div>
</div>
  </body>
