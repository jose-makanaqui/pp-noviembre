<?php
  include ("Conexión.php");
  // Obtengo los datos cargados en el formulario de obtencion de datos.
  $nombre= $_POST ['nombre'];
  $apellido= $_POST ['apellido'];
  $correo= $_POST ['correo'];
  $clave= $_POST ['clave'];
  $sql= "INSERT INTO usuarios (nombre, apellido, correo, clave) VALUES ('$nombre', '$apellido', '$correo', '$clave')";
  $envio_consulta= $conexión -> query ($sql);
  header ("Location: Iniciar-sesion.php");
?>